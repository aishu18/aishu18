package com.niit.cshop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.niit.cshop.dao.UserDao;
import com.niit.cshop.dao.UserDaoImpl;
import com.niit.cshop.model.ProductModel;
import com.niit.cshop.model.UserDetails;
import com.niit.cshop.service.ProductService;

@Controller
	public class HomeController {
	@Autowired
	private ProductService deviceData;
		
	@Autowired
		 private SessionFactory sessionFactory;
		String setName="";
		
		
		


		
		@RequestMapping("/")
		public ModelAndView getFirstPage(){	
			System.out.println("\n/request maped with welcome jsp");
			ModelAndView mv = new ModelAndView("welcome");
			return mv;
		}	
		

		@RequestMapping("/page0")
		public ModelAndView getPage1(){	
			System.out.println("\n/request maped with page0 jsp");
			ModelAndView mv = new ModelAndView("page0");
			return mv;
		}	
		
		@RequestMapping("/device")
		public ModelAndView AllProductCode(
				@RequestParam(value = "name", required = false, defaultValue = "DEVICE")String name) {
			System.out.println("\n/request maped with page1 jsp(alias device)");
			ModelAndView allprod = new ModelAndView("page1");
			setName = name;
			System.out.println(setName);
			return allprod;
		}
		@RequestMapping("/GsonCon")
		public @ResponseBody String getValues() {
				
			//ndd = new ProductDAOImpl();
			String devs="";
			
			if("alldev".equals(setName)){
				System.out.println("gson all devices...");
				List <ProductModel> listdev = deviceData.getAllDevices();
				Gson gson = new Gson();
				devs=gson.toJson(listdev);
				System.out.println("at the end of all devices");
			}
			else{		
				System.out.println("gson one device...");
				ProductModel nd = ProductModel.getProduct(setName);
				List <ProductModel> ld = new ArrayList<ProductModel>();
				ld.add(nd);
				Gson gson=new Gson();
				devs=gson.toJson(ld);
				System.out.println("at the end of one device");
			}
			return devs;
			
		}
		@RequestMapping("/GsonConAdmin")
		public @ResponseBody String getadminValues() {
				
			String products="";
			System.out.println("gsonconproducts- " );
				System.out.println("gson all products...");
				List <ProductModel> listproduct = deviceData.getAllDevices();
				Gson gson = new Gson();
				products=gson.toJson(listproduct);
			return products;
		}
		@RequestMapping("/GsonConUser")
		public @ResponseBody String getProValues() {
				
			String products="";
			System.out.println("gsonconproducts- " );
				System.out.println("gson all products...");
				List <ProductModel> listproduct = deviceData.getAllDevices();
				Gson gson = new Gson();
				products=gson.toJson(listproduct);
			return products;
		}
		
		@RequestMapping("/success")
		public ModelAndView getsuccess(){	
			System.out.println("\n/request maped with success jsp");
			ModelAndView mv = new ModelAndView("success");
			return mv;
		}
		
		@RequestMapping("/loginpage")
		public ModelAndView loginPage(){	
			System.out.println("\n/request maped with login jsp");
			ModelAndView mv = new ModelAndView("login");
			return mv;

}
		

		@RequestMapping("/logincheck") // from login.jsp
		public ModelAndView logincheck(@RequestParam(value="userid")String userid,@RequestParam(value="pwd")String passwd) {
			System.out.println("\nMyContoller - logincheck");
			ModelAndView mv;
			System.out.println("\nMyContoller - /loginCheck - before session factory");
			UserDao ud = new UserDaoImpl(sessionFactory);
			System.out.println("\nMyContoller - /loginCheck - after session factory");
			
			if(ud.isValidUser(userid,passwd)==true && ud.isAdminUser(userid,passwd)==true ) {
				System.out.println("login ok");
				mv=new ModelAndView("loginSuccessAdmin");
			}
			else if(ud.isValidUser(userid,passwd)==true) {
				System.out.println("login ok");
				mv=new ModelAndView("loginsuccessuser");
			}
			else {
				System.out.println("login not ok");			
				mv=new ModelAndView("loginerror");
			}
			return mv;	
		}
		@RequestMapping("/homeFromLogin")
		public ModelAndView getHomePage(){	
			System.out.println("\n/ request maped back to welcome from login success");
			ModelAndView mv = new ModelAndView("welcome");
			return mv;
		}
		@RequestMapping("/addDev") // from welcome.jsp
		public ModelAndView addDevice() {
			System.out.println("in add dev controller");
			System.out.println("\nMyContoller - addDev");
			ModelAndView mv = new ModelAndView("addDevice");
			return mv;
			//return null;
		}
		@RequestMapping("/addDevice") // from addDevice.jsp
	    public ModelAndView storeProduct(@RequestParam(value="ProductID")String did,@RequestParam(value="ProductName")String dn,
	    		@RequestParam(value="ProductCategory")String dcat,@RequestParam(value="ProductDetails")String ddet,
	    		@RequestParam(value="ProductPrice")String dprice,
	    		@RequestParam(value="ProductPhotoURL")String durl)
	    {
	    	System.out.println("In Add device method : " + dn );
	    	ProductModel p = new ProductModel();
	    	p.setProductID(Integer.parseInt(did));
	    	p.setProductName(dn);
	    	p.setProductCategory(dcat);
	    	p.setProductDetails(ddet);
	    	p.setProductPrice(Integer.parseInt(dprice));
	    	p.setProductPhotoURL(durl);    	
	    	//System.out.println("test:"+p.getDeviceName());
	    	
	    	deviceData.addDevice(p);
	    	//return new ModelAndView("ProductsAdded", "message", "");
	    	return null;
	    }
		

		@RequestMapping("/deleteDevice") // from page1.jsp
		public ModelAndView deleteDevice(@RequestParam(value="id")String did) {
		//	System.out.println("id:"+req.getParameter("DeviceId"));
			System.out.println(did);
			
			System.out.println("\nHomeContoller - deleteDevice - " + did);
//		int id = Integer.parseInt(did);
			deviceData.deleteDevice(did);
			System.out.println("\nHomeContoller - delDevice - " + did + " - completed");
			ModelAndView mv = new ModelAndView("page1");		
			return mv;		
		}
		@RequestMapping("/editDevice") // from page1.jsp
		public ModelAndView editDevice(@RequestParam(value="id")String did, HttpServletRequest request) {
		//	System.out.println("id:"+req.getParameter("DeviceId"));
			System.out.println(did);
			System.out.println("\nMyContoller - editDevicePage - " + did);
			int id = Integer.parseInt(did);
			//devserv.deleteDevice(id);
			ProductModel nd = new ProductModel();
			Session s = sessionFactory.openSession();
			ModelAndView mv = new ModelAndView("editDevicePage");
			
			ProductModel nd1 = (ProductModel)s.get(ProductModel.class,id);
			HttpSession session = request.getSession();
			session.setAttribute("data", nd1);				
			session.setAttribute("devid",did);
			mv.addObject("devid",did);
			mv.addObject("command",nd1);
			//String str=(String)session.getAtt
			//System.out.println("\nMyContoller - editDevicePage - " + id + " - completed");
			return mv;		
		}
		
		@RequestMapping("editProductData")
		public ModelAndView update(@ModelAttribute("abcd")ProductModel p) 
		 {
			deviceData.updateDevice(p);
			System.out.println("edit data success");
			return new ModelAndView("page1");  
			
		 }
		


		@RequestMapping("register")
		public ModelAndView registerUser(){
			ModelAndView mv = new ModelAndView("userregistration1");
			
			return mv;
		}

		//registerUser
		@RequestMapping("registerUser")
		public ModelAndView regUser(@RequestParam(value="userid")String uid,@RequestParam(value="password")String pwd,
	    		@RequestParam(value="emailid")String email,@RequestParam(value="mobilenumber")String mobile,
	    		@RequestParam(value="address")String addr,@RequestParam(value="city")String cit,
	    		@RequestParam(value="state")String st,@RequestParam(value="country")String cnt )
		{
			System.out.println("registeruser");
			UserDetails ud = new UserDetails();
			
			ud.setUserId(uid);
			ud.setPassword(pwd);
			ud.setAdmin(false);
			ud.setStatus("valid");
			ud.setEmailId(email);
			ud.setMobileNo(mobile);
			ud.setAddress(addr);
			ud.setCity(cit);
			ud.setState(st);
			ud.setCountry(cnt);		
			
			UserDao udao = new UserDaoImpl(sessionFactory);
			udao.addUser(ud);
			
			
			
			return null;
		}
		
		
	}


				
			
			



package com.niit.cshop.dao;

import java.util.List;

import com.niit.cshop.model.CategoryModel;

public interface CategoryDao {

	public List<CategoryModel> getCategoryList();

	public void addCategory(CategoryModel c);

	public Object deleteCategory(String cid);

	public void editCategory(CategoryModel ndm);



}

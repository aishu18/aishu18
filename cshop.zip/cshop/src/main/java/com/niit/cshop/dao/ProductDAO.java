package com.niit.cshop.dao;

import java.util.List;

import com.niit.cshop.model.ProductModel;

public interface ProductDAO {
	public List<ProductModel> getAllDevices();
	public ProductModel getDevice(String did);
	public String editDevice(ProductModel ndm);

	public void addDevice(ProductModel ndm);
	
	public String deleteDevice(String did); 



}

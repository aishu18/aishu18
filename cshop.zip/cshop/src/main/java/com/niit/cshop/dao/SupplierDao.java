package com.niit.cshop.dao;

import java.util.List;

import com.niit.cshop.model.SupplierModel;

public interface SupplierDao {

	public List<SupplierModel> getSupplierList();
	public void addSupplier(SupplierModel ndm); 
	public String deleteSupplier(String sid);
	public String editSupplier(SupplierModel ndm);
}

package com.niit.cshop.dao;

import com.niit.cshop.model.UserDetails;

public interface UserDao {
	
	public boolean isValidUser(String userid, String passwd);
	public boolean isAdminUser(String un, String pd);
	public void addUser(UserDetails ud);
	


}

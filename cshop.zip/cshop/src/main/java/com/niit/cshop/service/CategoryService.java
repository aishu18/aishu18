package com.niit.cshop.service;

import java.util.List;

import com.niit.cshop.model.CategoryModel;

public interface CategoryService {

	List<CategoryModel> getCategoryList();

	void addCategory(CategoryModel c);

	void deleteCategory(String cid);

	void updateCategory(CategoryModel c);

}

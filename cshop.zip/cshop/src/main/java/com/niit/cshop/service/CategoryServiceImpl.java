package com.niit.cshop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.cshop.dao.CategoryDao;
import com.niit.cshop.model.CategoryModel;

@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
	private	 CategoryDao categorydao;
	


	public List<CategoryModel> getCategoryList() {
		
		// TODO Auto-generated method stub
		System.out.println("In SERVICE");
		List<CategoryModel> a=categorydao.getCategoryList();
		System.out.println(a);
		return a;
	
}


	
	public void addCategory(CategoryModel c) {
		// TODO Auto-generated method stub

			System.out.println("In Categeoryserviceimpl");
			categorydao.addCategory(c); 
			
		}
	public void deleteCategory(String cid) {
		// TODO Auto-generated method stub
		System.out.println("\nDelete-service");
		 categorydao.deleteCategory(cid);
	
	}
	public void updateCategory(CategoryModel c) {
		/// TODO Auto-generated method stub
		categorydao.editCategory(c);
		
	}


		
	}


package com.niit.cshop.service;

import java.util.List;

import com.niit.cshop.model.ProductModel;
import com.niit.cshop.model.UserDetails;

public interface ProductService {

	List<ProductModel> getAllDevices();

	public void addDevice(ProductModel ndm);
	public ProductModel getDevice(String did);
	public String updateDevice(ProductModel ndm);
	public String deleteDevice(String did); 
	public ProductModel getProduct(String setName);
	
	
	
	}


package com.niit.cshop.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.cshop.dao.ProductDAO;
import com.niit.cshop.dao.UserDao;
import com.niit.cshop.model.ProductModel;
import com.niit.cshop.model.UserDetails;
@Service
public class ProductServiceImpl implements ProductService{	
	
	//@Autowired
		private UserDao udao;
		
	@Autowired
	private ProductDAO deviceData;
	
	public List<ProductModel> getAllDevices() {
		// TODO Auto-generated method stub
		System.out.println("\nProductModelServ-getAllDev()");
		return deviceData.getAllDevices();
	}

	
	public void addDevice(ProductModel ndm) {
		// TODO Auto-generated method stub
		System.out.println("\nProductModelServ-addDevice()");
		deviceData.addDevice(ndm); 
	}

	
	public ProductModel getDevice(String did) {
		// TODO Auto-generated method stub
		System.out.println("\nProductModelServ-getDevice()");
		return deviceData.getDevice(did);
	}

	
	



	public String deleteDevice(String did) {
		// TODO Auto-generated method stub
		 deviceData.deleteDevice(did);
		return null;
	
	}

	public String updateDevice(ProductModel ndm) {
		// TODO Auto-generated method stub
		deviceData.editDevice(ndm);
		return null;
	}
	
	public ProductModel getProduct(String setName) {
		// TODO Auto-generated method stub
		return null;
	}


	


	
	
		

		
	
}


